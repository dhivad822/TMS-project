# Timetable Management System — Upgrade Notes

## How to run
```
pip install -r requirements.txt
python app.py
```
Then open http://localhost:5000

## Logins
- **Admin:** username `admin`, password `admin123` (unchanged from before)
- **Staff:** Staff ID + password. Each staff member's **default password is their own Staff ID**
  (e.g. Staff ID `T001` logs in with password `T001`). There isn't a "change password" screen yet —
  let me know if you'd like that added.

## What's new — v2 (this update)
- **Customizable Period Rows:** New "Customize Periods" button on the Timetable Editor opens a modal
  where Admin can add, rename, retime, reorder, or remove period rows, and mark any row as a "Break"
  (like Lunch). Editing a period's label/time keeps assignments already saved in that slot — only
  *deleting* a period hides what was in it. Applies across every department's timetable.
- **Per-Department Timetables:** Each department now has its own separately saved timetable. A
  Department dropdown on the Timetable Editor switches which one you're viewing/editing; Save,
  AI Generate, and Export Excel all act on the currently selected department, and AI Generate now
  only assigns staff who belong to that department. Staff members' "My Timetable" and dashboard
  automatically show their own department's schedule.
- **Login headline:** Both the Admin and Staff login pages now show a bold "TIMETABLE MANAGEMENT"
  headline above the login card.
- Existing timetable data (if any) is auto-migrated on first load into a "General" department bucket
  so nothing is lost; the class-reminder scheduler was updated to work with the new per-department,
  per-custom-period structure.

## What's new — v1
- **Role-based accounts:** Staff now get their own login and a read-only dashboard/timetable view.
  Admin-only pages (Staff, Departments, Settings, Email Center, editing the Timetable, changing System
  Time) are blocked for Staff accounts.
- **System Date & Time:** New "System Time" page. Admin can set a custom date/time (useful for demos/
  testing); Staff can only view it, live-ticking. Resetting it returns to the real device clock. This
  is a display/administration feature — it does **not** change the real server clock or affect the
  existing 15-minutes-before-class reminder scheduler, which still runs off real time exactly as before.
- **Email Center:**
  - Automatic email generator — enter a topic (+ optional key points and tone), and it drafts a
    professional subject/body you can edit before sending. This is a built-in template generator, not
    a call to an external AI service (no AI API key was configured in the project).
  - **Send Email to All Staff** — one-click send to every registered staff member.
  - **Start / Stop** auto-send — repeats the same email to all staff every N minutes (default 5) until
    you click Stop. Runs in a background thread; the page shows live status (run count, last sent time).
  - Requires SMTP to be configured first under **Settings** (same email settings the app already used).
- **Email History page:** every manual and auto-sent announcement, with recipient/sent/failed counts.
- **Dashboard:** added Emails Sent + Auto-Send status cards, animated counters, and a staff-by-department
  breakdown.
- **UI:** new animated gradient background, glass-style cards, hover/entry animations, toast-style flash
  messages, and a fully responsive/mobile-friendly layout. All of this was done via the CSS/JS layer, so
  the original page markup — and therefore all original functionality — is untouched.

## Everything that already worked still works
Staff upload/add/delete, departments, timetable editor + AI-shuffle generator + Excel export, SMTP
settings, and the original class-reminder scheduler were not modified in behavior beyond what was
needed for per-department storage — only re-styled otherwise. I tested each of these routes plus
every new one (including customizing periods and switching departments) before packaging this.

## One thing worth knowing
The dev server (`python app.py`) is fine for local use/demos but isn't meant for production hosting —
if you plan to deploy this somewhere permanent, it should sit behind a real WSGI server (e.g. gunicorn)
with HTTPS. Happy to help with that if/when you get there.

## What's new — v3 (Campus Care merge + Timetable email automation)

### Campus Fix / CampusFix merge
- **Firebase removed completely.** CampusFix now stores tickets in `data/campus_tickets.json` —
  the same JSON-file database Timetable Management already uses. No external service, no API keys.
- **Single login.** CampusFix's old Student/Staff/Admin tab login (with its own hardcoded admin
  password) is gone. Opening `/campus-care` now automatically signs you in as whichever
  Timetable Management account you're already logged in as (Admin or Staff) — no second login screen.
  A staff member can still file a ticket "on behalf of" a student using the editable
  **Reporting As** field on the Submit Request form.
- **Redesigned to match Timetable Management's look** — same indigo/teal palette, gradient
  background, and fonts (Poppins/Inter) as the rest of the app, instead of its old dark theme.
- All original CampusFix features still work as before: submitting requests, categories,
  status/priority filters, admin Manage Tickets, comments, likes, analytics, rename app,
  seed demo data — just backed by the new API (`/campus-care/api/...`) instead of Firestore.

### Timetable-based email automation
- New **"Timetable-Based Reminders"** panel on the Email Center page with a
  **Start Auto Sending** / **Stop** button.
- Once started, a background job checks every minute, reads every department's live timetable,
  and emails each assigned staff member **15 minutes before their period** — continuing
  automatically, day after day, with no manual action needed per period.
- Every reminder email includes two links:
  - **ALERT** — staff clicks to confirm they've seen it (recorded, no login needed).
  - **STOP** — staff clicks to permanently silence reminders for that recurring class slot.
- No duplicate emails: each exact date+department+day+period+staff combination is only ever
  sent once, and this is tracked in `data/timetable_email_log.json`, which survives restarts.
- New **Timetable Reminder Log** page (under the Email menu) shows every reminder sent, its
  delivery status, and whether/when it was alerted or stopped.
- **Note on links:** the ALERT/STOP links are built from `APP_BASE_URL` (defaults to
  `http://localhost:5000`). If you deploy this somewhere else, set the `APP_BASE_URL`
  environment variable (e.g. `APP_BASE_URL=https://your-domain.com`) before starting the app,
  otherwise the links in the emails won't be reachable from outside your machine.

---

## Update: Student Login + Email Generator Defaults + Complaint STOP/ALERT STAFF

No existing design, colors, layout, or functionality were changed. Everything below is additive.

### 1. Student Login (new, separate from Admin/Staff)
- New login at **/student-login** (also linked from the Admin and Staff login pages).
- Default password = the Student ID (Admin can add students under **Students** in the nav).
- Students get their own dashboard (**/student-dashboard**) and a **view-only Smart Timetable**
  (**/student-timetable**) that automatically shows their Department, Class, and Semester, and
  the timetable for their department — no editing controls.
- Students can open CampusFix to submit/track complaints, but never see any Admin/Staff-only
  screens (Manage Tickets, Staff, Students, Departments, Email Center, Settings, etc.) — those
  routes require an Admin (or Staff, where already allowed) session and redirect otherwise.

### 2. Dynamic Class Management
- New **Add Class** panel on the **Departments** page — Admin can add/delete Classes, each tied
  to a Department and Semester. Students, Classes, and Departments are linked by name.

### 3. Email Message Generator — Default Messages
- New **Default Messages** card on **Email Center**: pick a ready-made message (Class Cancelled,
  Exam Reminder, Holiday Notice, Meeting Notice, General Announcement, Complaint Follow-Up) and
  insert it straight into the compose box, or still use the AI-style generator as before.

### 4. Complaint Notifications — STOP & ALERT STAFF
- Opening a complaint as Admin in CampusFix now shows a **Staff Notifications** panel:
  - **Assign** a staff member to start a recurring reminder email about that complaint.
  - **STOP** halts the recurring reminder for *that one complaint only* — every other
    complaint's reminders, and the background scheduler itself, keep running.
  - **ALERT STAFF** stops the current reminder, reassigns the complaint to another staff member
    (preferring the same department), and immediately emails the new staff member.
  - Resolving a ticket automatically stops its own reminder loop.
- A dedicated background thread (`complaint_notify_scheduler`) checks every minute and is
  started once when the server boots — it keeps running even if every browser tab is closed or
  everyone logs out, and every send is written to a persistent history
  (**Complaint Notify Log**, linked under the Email menu) so duplicate/failed sends are visible.

### 5. Timetable Reminder Timing — now truly always-on
- The existing timetable-based staff email reminders now fire **5 minutes** before each period
  (previously 15), still skipping breaks, still deduplicated, still independent per period (a
  STOP on one period never touches the rest of the day's schedule).
- The scheduler thread now **starts automatically the moment the server boots** — Admin no
  longer has to click Start after every restart. The Start/Stop button on Email Center just
  flips a saved flag the always-running thread checks each minute, and that flag is honoured on
  every future restart too (if Admin stopped it, it stays stopped until Start is clicked again;
  a fresh install starts active by default). This makes the "browser closed / logged out /
  server restarted" reliability requirement fully automatic rather than depending on someone
  remembering to press Start.
