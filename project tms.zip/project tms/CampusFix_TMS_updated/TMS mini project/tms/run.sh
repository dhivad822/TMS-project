#!/bin/bash
echo "Starting Timetable AI Management System..."
echo "Installing dependencies (first time only)..."
pip install -r requirements.txt
echo ""
echo "Starting server..."
python app.py
