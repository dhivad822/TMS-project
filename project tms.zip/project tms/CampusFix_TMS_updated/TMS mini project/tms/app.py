import os
import json
import smtplib
import ssl
import pandas as pd
import random
import secrets
import threading
import time
from functools import wraps
from email.mime.text import MIMEText
from datetime import datetime, timedelta
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session, send_file, send_from_directory
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = 'timetable_management_secret_key_2026'

# Base URL used to build absolute links inside emails (ALERT/STOP, etc.),
# since those are built from a background thread with no active request.
# Override via the APP_BASE_URL environment variable if you deploy this
# somewhere other than http://localhost:5000.
APP_BASE_URL = os.environ.get('APP_BASE_URL', 'http://localhost:5000').rstrip('/')

# Paths
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, 'data')
UPLOAD_DIR = os.path.join(BASE_DIR, 'uploads')

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(UPLOAD_DIR, exist_ok=True)

# Data files
STAFF_FILE = os.path.join(DATA_DIR, 'staff.json')
TIMETABLE_FILE = os.path.join(DATA_DIR, 'timetable.json')
ADMIN_FILE = os.path.join(DATA_DIR, 'admin.json')
NOTIFICATIONS_FILE = os.path.join(DATA_DIR, 'notifications.json')
DEPARTMENTS_FILE = os.path.join(DATA_DIR, 'departments.json')
SMTP_CONFIG_FILE = os.path.join(DATA_DIR, 'smtp_config.json')
SYSTEM_TIME_FILE = os.path.join(DATA_DIR, 'system_time.json')
EMAIL_HISTORY_FILE = os.path.join(DATA_DIR, 'email_history.json')
AUTO_EMAIL_STATE_FILE = os.path.join(DATA_DIR, 'auto_email_state.json')
PERIODS_FILE = os.path.join(DATA_DIR, 'periods.json')
CAMPUS_TICKETS_FILE = os.path.join(DATA_DIR, 'campus_tickets.json')
TIMETABLE_EMAIL_LOG_FILE = os.path.join(DATA_DIR, 'timetable_email_log.json')
TIMETABLE_AUTO_STATE_FILE = os.path.join(DATA_DIR, 'timetable_auto_state.json')
STUDENTS_FILE = os.path.join(DATA_DIR, 'students.json')
CLASSES_FILE = os.path.join(DATA_DIR, 'classes.json')
COMPLAINT_NOTIFY_LOG_FILE = os.path.join(DATA_DIR, 'complaint_notify_log.json')

# Admin credentials (default)
def init_admin():
    if not os.path.exists(ADMIN_FILE):
        admin_data = {
            'username': 'admin',
            'password': generate_password_hash('admin123')
        }
        with open(ADMIN_FILE, 'w') as f:
            json.dump(admin_data, f)

init_admin()

# ==================== STAFF ====================

def load_staff():
    if os.path.exists(STAFF_FILE):
        with open(STAFF_FILE, 'r') as f:
            staff_list = json.load(f)
        # Migrate older records that don't have a login password yet.
        # Default staff password is their Staff ID.
        changed = False
        for member in staff_list:
            if not member.get('password_hash'):
                member['password_hash'] = generate_password_hash(str(member.get('id', '')))
                changed = True
        if changed:
            save_staff(staff_list)
        return staff_list
    return []

def save_staff(staff_list):
    with open(STAFF_FILE, 'w') as f:
        json.dump(staff_list, f, indent=2)

# ==================== STUDENTS ====================
# Student accounts are a separate, limited-access login. Each student is
# linked (by name, not by duplicating data) to a Department and a Class,
# and their Semester is stored directly on their record. Default login
# password is their own Student/Register ID, exactly like Staff.

def load_students():
    if os.path.exists(STUDENTS_FILE):
        with open(STUDENTS_FILE, 'r') as f:
            students_list = json.load(f)
        changed = False
        for member in students_list:
            if not member.get('password_hash'):
                member['password_hash'] = generate_password_hash(str(member.get('id', '')))
                changed = True
        if changed:
            save_students(students_list)
        return students_list
    return []

def save_students(students_list):
    with open(STUDENTS_FILE, 'w') as f:
        json.dump(students_list, f, indent=2)

# ==================== CLASSES ====================
# Classes are dynamically managed by Admin, each tied to a Department and
# a Semester (e.g. "CSE - A" / Semester 4). Students reference a class by
# name, which is how Students, Classes, and Departments stay connected.

def load_classes():
    if os.path.exists(CLASSES_FILE):
        with open(CLASSES_FILE, 'r') as f:
            return json.load(f)
    return []

def save_classes(classes_list):
    with open(CLASSES_FILE, 'w') as f:
        json.dump(classes_list, f, indent=2)

# Timetable management — timetables are stored per department:
# { "CSE": { "Monday": { "p1": {...} } }, "IT": { ... } }
def load_all_timetables():
    if os.path.exists(TIMETABLE_FILE):
        with open(TIMETABLE_FILE, 'r') as f:
            data = json.load(f)
        # Migrate a legacy single flat timetable (day -> period -> details) that
        # predates per-department storage into a "General" bucket so no data is lost.
        day_names = {'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'}
        if isinstance(data, dict) and any(k in day_names for k in data.keys()):
            data = {'General': data}
            save_all_timetables(data)
        return data
    return {}

def save_all_timetables(data):
    with open(TIMETABLE_FILE, 'w') as f:
        json.dump(data, f, indent=2)

def get_department_timetable(department):
    if not department:
        return {}
    return load_all_timetables().get(department, {})

def save_department_timetable(department, table):
    all_tt = load_all_timetables()
    all_tt[department] = table
    save_all_timetables(all_tt)

# Period rows (the columns of the timetable grid) — fully customizable by Admin.
# Kept separate from the display label/time so editing a period's time later
# doesn't disconnect it from assignments already saved against it.
DEFAULT_PERIODS = [
    {'id': 'p1', 'label': 'Period 1', 'start': '9:00', 'end': '10:00', 'is_break': False},
    {'id': 'p2', 'label': 'Period 2', 'start': '10:00', 'end': '11:00', 'is_break': False},
    {'id': 'p3', 'label': 'Period 3', 'start': '11:00', 'end': '12:00', 'is_break': False},
    {'id': 'p4', 'label': 'Period 4', 'start': '12:00', 'end': '1:00', 'is_break': False},
    {'id': 'lunch', 'label': 'Lunch', 'start': '1:00', 'end': '2:00', 'is_break': True},
    {'id': 'p5', 'label': 'Period 5', 'start': '2:00', 'end': '3:00', 'is_break': False},
    {'id': 'p6', 'label': 'Period 6', 'start': '3:00', 'end': '4:00', 'is_break': False},
    {'id': 'p7', 'label': 'Period 7', 'start': '4:00', 'end': '5:00', 'is_break': False},
]

def load_periods():
    if os.path.exists(PERIODS_FILE):
        with open(PERIODS_FILE, 'r') as f:
            periods = json.load(f)
        if periods:
            return periods
    save_periods(DEFAULT_PERIODS)
    return DEFAULT_PERIODS

def save_periods(periods):
    with open(PERIODS_FILE, 'w') as f:
        json.dump(periods, f, indent=2)

def period_display(p):
    return f"{p.get('label', '')} ({p.get('start', '')}-{p.get('end', '')})"

# Notifications
def load_notifications():
    if os.path.exists(NOTIFICATIONS_FILE):
        with open(NOTIFICATIONS_FILE, 'r') as f:
            return json.load(f)
    return []

def save_notifications(notifications):
    with open(NOTIFICATIONS_FILE, 'w') as f:
        json.dump(notifications, f, indent=2)

# Departments
def load_departments():
    if os.path.exists(DEPARTMENTS_FILE):
        with open(DEPARTMENTS_FILE, 'r') as f:
            return json.load(f)
    default_departments = ['CSE', 'IT', 'ECE', 'EEE', 'MECH', 'CIVIL']
    save_departments(default_departments)
    return default_departments

def save_departments(departments):
    with open(DEPARTMENTS_FILE, 'w') as f:
        json.dump(departments, f, indent=2)

# SMTP / Email configuration
def load_smtp_config():
    if os.path.exists(SMTP_CONFIG_FILE):
        with open(SMTP_CONFIG_FILE, 'r') as f:
            return json.load(f)
    default_config = {
        'smtp_server': 'smtp.gmail.com',
        'smtp_port': 587,
        'sender_email': '',
        'sender_password': '',
        'use_tls': True
    }
    save_smtp_config(default_config)
    return default_config

def save_smtp_config(config):
    with open(SMTP_CONFIG_FILE, 'w') as f:
        json.dump(config, f, indent=2)

def send_email(to_email, subject, body):
    """Send a real email via SMTP. Returns (success: bool, message: str)."""
    config = load_smtp_config()

    if not config.get('sender_email') or not config.get('sender_password'):
        return False, 'SMTP is not configured yet. Go to Settings and add your email credentials.'

    if not to_email:
        return False, 'No recipient email address provided.'

    try:
        msg = MIMEText(body)
        msg['Subject'] = subject
        msg['From'] = config['sender_email']
        msg['To'] = to_email

        server = smtplib.SMTP(config['smtp_server'], int(config['smtp_port']), timeout=15)
        if config.get('use_tls', True):
            server.starttls(context=ssl.create_default_context())
        server.login(config['sender_email'], config['sender_password'])
        server.sendmail(config['sender_email'], [to_email], msg.as_string())
        server.quit()
        return True, 'Email sent successfully.'
    except Exception as e:
        return False, f'Email failed: {str(e)}'

# ==================== EMAIL HISTORY ====================

def load_email_history():
    if os.path.exists(EMAIL_HISTORY_FILE):
        with open(EMAIL_HISTORY_FILE, 'r') as f:
            return json.load(f)
    return []

def save_email_history(history):
    with open(EMAIL_HISTORY_FILE, 'w') as f:
        json.dump(history, f, indent=2)

def dispatch_bulk_email(subject, body, source='manual'):
    """Sends subject/body to every registered staff member and logs one
    aggregated entry to the Email History."""
    staff = load_staff()
    sent, failed = 0, 0
    for s in staff:
        ok, info = send_email(s.get('email_id', ''), subject, body)
        if ok:
            sent += 1
        else:
            failed += 1

    history = load_email_history()
    entry = {
        'id': len(history) + 1,
        'subject': subject,
        'body': body,
        'recipients': len(staff),
        'sent': sent,
        'failed': failed,
        'source': source,
        'sent_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    }
    history.append(entry)
    save_email_history(history)
    return sent, failed, len(staff)

def generate_email_content(topic, key_points_raw='', tone='formal', sender_name='Administration'):
    """Rule-based professional email generator. Produces a polished subject
    and body for a given announcement topic without requiring any external
    AI service or API key."""
    topic = (topic or 'a general announcement').strip()
    key_points = [p.strip() for p in (key_points_raw or '').split('\n') if p.strip()]

    if tone == 'urgent':
        subject = f'Urgent Notice: {topic}'
        intro = f'This is an urgent notification regarding {topic.lower()} that requires your prompt attention.'
    elif tone == 'friendly':
        subject = f'A Quick Update: {topic}'
        intro = f"Hope you're having a great day! I wanted to share a quick update about {topic.lower()}."
    else:
        subject = f'Important Update: {topic}'
        intro = f"I hope this message finds you well. I'm writing to share an important update regarding {topic.lower()}."

    lines = ['Dear Team,', '', intro, '']
    if key_points:
        lines.append('Key details:')
        for kp in key_points:
            lines.append(f'  • {kp}')
        lines.append('')
    lines.append('Please do not hesitate to reach out to the administration office if you have any '
                  'questions or need further clarification.')
    lines.append('')
    lines.append('Best regards,')
    lines.append(sender_name or 'Administration')

    return subject, '\n'.join(lines)

# Ready-made default messages for the Email Message Generator, so Admin/Staff
# can send a common announcement in one click without typing it from scratch.
DEFAULT_EMAIL_TEMPLATES = [
    {
        'key': 'class_cancelled',
        'label': 'Class Cancelled',
        'subject': 'Notice: Class Cancelled',
        'body': ("Dear Team,\n\nThis is to inform you that today's class/session stands cancelled due to "
                 "unforeseen circumstances. The rescheduled date and time will be communicated shortly.\n\n"
                 "We regret any inconvenience caused.\n\nBest regards,\nAdministration")
    },
    {
        'key': 'exam_reminder',
        'label': 'Exam Reminder',
        'subject': 'Reminder: Upcoming Examination',
        'body': ("Dear Team,\n\nThis is a reminder that examinations are scheduled shortly. Kindly ensure "
                 "you are well prepared and report on time with the required materials/hall ticket.\n\n"
                 "For any queries, please contact the administration office.\n\nBest regards,\nAdministration")
    },
    {
        'key': 'holiday_notice',
        'label': 'Holiday Notice',
        'subject': 'Notice: Holiday Announcement',
        'body': ("Dear Team,\n\nPlease be informed that the institution will remain closed for the "
                 "upcoming holiday. Regular classes/duties will resume on the next working day.\n\n"
                 "Best regards,\nAdministration")
    },
    {
        'key': 'meeting_notice',
        'label': 'Meeting Notice',
        'subject': 'Notice: Meeting Scheduled',
        'body': ("Dear Team,\n\nA meeting has been scheduled shortly. Kindly make yourself available "
                 "and come prepared with any relevant updates.\n\nBest regards,\nAdministration")
    },
    {
        'key': 'general_announcement',
        'label': 'General Announcement',
        'subject': 'General Announcement',
        'body': ("Dear Team,\n\nThis is a general announcement from the administration. Please review "
                  "and reach out with any questions.\n\nBest regards,\nAdministration")
    },
    {
        'key': 'complaint_followup',
        'label': 'Complaint Follow-Up',
        'subject': 'Follow-Up: Reported Complaint',
        'body': ("Dear Staff,\n\nThis is a follow-up regarding a complaint raised through CampusFix that "
                 "is still pending your attention. Kindly review and take the necessary action at the "
                 "earliest.\n\nBest regards,\nAdministration")
    },
]

# ==================== SYSTEM DATE & TIME ====================

def load_system_time_state():
    default = {'base_real': None, 'base_custom': None, 'set_by': None}
    if os.path.exists(SYSTEM_TIME_FILE):
        with open(SYSTEM_TIME_FILE, 'r') as f:
            data = json.load(f)
            default.update(data)
    return default

def save_system_time_state(state):
    with open(SYSTEM_TIME_FILE, 'w') as f:
        json.dump(state, f, indent=2)

def get_effective_system_time():
    """Returns the current system time, adjusted for any custom date/time
    the Admin has set. Falls back to the real device clock otherwise."""
    state = load_system_time_state()
    if not state.get('base_real') or not state.get('base_custom'):
        return datetime.now()
    try:
        base_real = datetime.strptime(state['base_real'], '%Y-%m-%d %H:%M:%S')
        base_custom = datetime.strptime(state['base_custom'], '%Y-%m-%d %H:%M:%S')
        elapsed = datetime.now() - base_real
        return base_custom + elapsed
    except Exception:
        return datetime.now()

# ==================== AUTOMATIC EMAIL SENDER ====================

auto_email_stop_event = threading.Event()
auto_email_lock = threading.Lock()
auto_email_thread = None

def load_auto_email_state():
    default = {
        'active': False, 'subject': '', 'body': '', 'interval_seconds': 300,
        'started_at': None, 'last_run_at': None, 'run_count': 0
    }
    if os.path.exists(AUTO_EMAIL_STATE_FILE):
        with open(AUTO_EMAIL_STATE_FILE, 'r') as f:
            default.update(json.load(f))
    return default

def save_auto_email_state(state):
    with open(AUTO_EMAIL_STATE_FILE, 'w') as f:
        json.dump(state, f, indent=2)

def reset_auto_email_on_boot():
    """If the app restarted while an auto-send job was marked active, there is
    no live thread for it anymore, so mark it stopped."""
    state = load_auto_email_state()
    if state.get('active'):
        state['active'] = False
        save_auto_email_state(state)

reset_auto_email_on_boot()

def auto_email_worker(subject, body, interval_seconds):
    while not auto_email_stop_event.is_set():
        try:
            dispatch_bulk_email(subject, body, source='auto')
        except Exception as e:
            print(f'Auto-email send error: {e}')

        state = load_auto_email_state()
        if not state.get('active'):
            break
        state['run_count'] = state.get('run_count', 0) + 1
        state['last_run_at'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        save_auto_email_state(state)

        auto_email_stop_event.wait(interval_seconds)

# ==================== TIMETABLE-BASED EMAIL AUTOMATION ====================
# Reads the live per-department timetable and, once started, automatically
# emails each staff member ahead of their period. Every email carries two
# links (ALERT / STOP) that work without logging in, backed by a per-send
# unique token so the same period is never re-notified after either link
# is clicked, and the log persists across restarts.

timetable_auto_lock = threading.Lock()

def load_timetable_auto_state():
    default = {'active': True, 'started_at': None, 'last_check_at': None, 'sent_count': 0}
    if os.path.exists(TIMETABLE_AUTO_STATE_FILE):
        with open(TIMETABLE_AUTO_STATE_FILE, 'r') as f:
            default.update(json.load(f))
    return default

def save_timetable_auto_state(state):
    with open(TIMETABLE_AUTO_STATE_FILE, 'w') as f:
        json.dump(state, f, indent=2)

def reset_timetable_auto_on_boot():
    # The scheduler thread itself is always started at boot (see bottom of
    # this file) and just checks this 'active' flag every minute — so
    # whatever Admin last chose (Start/Stop) is honoured automatically on
    # every restart, with no need to click Start again.
    state = load_timetable_auto_state()
    if not os.path.exists(TIMETABLE_AUTO_STATE_FILE):
        state['started_at'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        save_timetable_auto_state(state)

reset_timetable_auto_on_boot()

def load_timetable_email_log():
    if os.path.exists(TIMETABLE_EMAIL_LOG_FILE):
        with open(TIMETABLE_EMAIL_LOG_FILE, 'r') as f:
            return json.load(f)
    return []

def save_timetable_email_log(log):
    with open(TIMETABLE_EMAIL_LOG_FILE, 'w') as f:
        json.dump(log, f, indent=2)

def timetable_notify_build_message(staff_name, department, day, period, subject_name, date_str):
    body = (
        f"Dear {staff_name},\n\n"
        f"This is a reminder of your upcoming class:\n\n"
        f"  Department : {department}\n"
        f"  Day / Date : {day}, {date_str}\n"
        f"  Period     : {period_display(period)}\n"
        f"  Subject    : {subject_name}\n\n"
        f"Please click ALERT below to confirm you've seen this reminder, "
        f"or STOP to stop further reminders for this class.\n"
    )
    return 'Timetable Reminder — Upcoming Class', body

def timetable_auto_worker():
    # Runs continuously from the moment the server boots - independent of
    # any browser tab, admin session, or login state. Every minute it checks
    # the 'active' flag: when active, it finds periods starting in ~5 minutes
    # today, for every department, and emails the assigned staff member once
    # (deduped by a unique date+department+day+period+staff key), unless they
    # had previously clicked STOP for that same recurring slot. Breaks
    # (is_break periods) are always skipped. This loop itself IS the full-day
    # scheduler: a STOP click on one period only marks that one slot as
    # stopped in the log - it never touches this loop or the 'active' flag,
    # so every other period keeps being notified normally, all day, every
    # day, with no manual restart needed.
    while True:
        try:
            state = load_timetable_auto_state()
            if not state.get('active'):
                time.sleep(60)
                continue

            now = get_effective_system_time()
            today_str = now.strftime('%Y-%m-%d')
            today_day = now.strftime('%A')
            all_timetables = load_all_timetables()
            staff = load_staff()
            period_by_id = {p['id']: p for p in load_periods()}
            log = load_timetable_email_log()
            log_keys = {entry['key']: entry for entry in log}
            # Slot key (no date) lets a STOP click permanently silence that
            # recurring department+day+period+staff slot, not just today.
            stopped_slots = {
                f"{e['department']}|{e['day']}|{e['period_id']}|{e['staff_id']}"
                for e in log if e.get('stopped')
            }
            sent_this_round = 0

            for department, timetable in all_timetables.items():
                day_periods = timetable.get(today_day, {})
                for period_id, details in day_periods.items():
                    p = period_by_id.get(period_id)
                    if not p or p.get('is_break') or not p.get('start'):
                        continue
                    staff_id = details.get('staff_id')
                    if not staff_id:
                        continue
                    try:
                        start_time = datetime.strptime(p['start'].strip(), '%H:%M')
                    except ValueError:
                        continue
                    notify_time = (start_time - timedelta(minutes=5)).strftime('%H:%M')
                    if now.strftime('%H:%M') != notify_time:
                        continue

                    key = f"{today_str}|{department}|{today_day}|{period_id}|{staff_id}"
                    if key in log_keys:
                        # Already sent for this exact period today — never resend.
                        continue
                    slot_key = f"{department}|{today_day}|{period_id}|{staff_id}"
                    if slot_key in stopped_slots:
                        # Staff clicked STOP for this recurring slot previously.
                        continue

                    staff_member = next((s for s in staff if s['id'] == staff_id), None)
                    if not staff_member:
                        continue

                    subject_name = details.get('subject', 'class')
                    email_subject, email_body_base = timetable_notify_build_message(
                        staff_member['name'], department, today_day, p, subject_name, today_str
                    )
                    token = secrets.token_urlsafe(24)
                    alert_url = f"{APP_BASE_URL}/email-action/alert/{token}"
                    stop_url = f"{APP_BASE_URL}/email-action/stop/{token}"
                    email_body = (
                        f"{email_body_base}\n"
                        f"ALERT (confirm seen): {alert_url}\n"
                        f"STOP (stop future reminders for this class): {stop_url}\n"
                    )
                    success, info = send_email(staff_member.get('email_id', ''), email_subject, email_body)

                    entry = {
                        'key': key, 'token': token,
                        'staff_id': staff_id, 'staff_name': staff_member['name'],
                        'department': department, 'day': today_day, 'period_id': period_id,
                        'subject': subject_name, 'date': today_str,
                        'sent_at': now.strftime('%Y-%m-%d %H:%M:%S'),
                        'status': 'Sent' if success else f'Failed - {info}',
                        'alerted': False, 'alerted_at': None,
                        'stopped': False, 'stopped_at': None,
                    }
                    log.append(entry)
                    log_keys[key] = entry
                    sent_this_round += 1

            save_timetable_email_log(log)

            state = load_timetable_auto_state()
            state['last_check_at'] = now.strftime('%Y-%m-%d %H:%M:%S')
            state['sent_count'] = state.get('sent_count', 0) + sent_this_round
            save_timetable_auto_state(state)
        except Exception as e:
            print(f'Timetable auto-email error: {e}')

        time.sleep(60)

# ==================== AUTH DECORATORS ====================

def is_admin():
    return 'admin_logged_in' in session

def is_staff():
    return 'staff_logged_in' in session

def is_student():
    return 'student_logged_in' in session

def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not is_admin() and not is_staff() and not is_student():
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return wrapper

def admin_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not is_admin():
            flash('That page is restricted to Admin accounts.', 'danger')
            if is_staff():
                return redirect(url_for('staff_dashboard'))
            if is_student():
                return redirect(url_for('student_dashboard'))
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return wrapper

def student_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not is_student():
            return redirect(url_for('student_login'))
        return f(*args, **kwargs)
    return wrapper

# ==================== ROUTES ====================

@app.route('/')
def index():
    if 'admin_logged_in' in session:
        return redirect(url_for('dashboard'))
    if 'staff_logged_in' in session:
        return redirect(url_for('staff_dashboard'))
    if 'student_logged_in' in session:
        return redirect(url_for('student_dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        with open(ADMIN_FILE, 'r') as f:
            admin = json.load(f)

        if username == admin['username'] and check_password_hash(admin['password'], password):
            session['admin_logged_in'] = True
            session['admin_username'] = username
            flash('Login successful!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid credentials!', 'danger')

    return render_template('login.html')

@app.route('/staff-login', methods=['GET', 'POST'])
def staff_login():
    if request.method == 'POST':
        staff_id = request.form.get('staff_id', '').strip()
        password = request.form.get('password', '')

        staff = load_staff()
        member = next((s for s in staff if s['id'] == staff_id), None)

        if member and check_password_hash(member.get('password_hash', ''), password):
            session['staff_logged_in'] = True
            session['staff_id'] = member['id']
            session['staff_name'] = member['name']
            flash(f"Welcome, {member['name']}!", 'success')
            return redirect(url_for('staff_dashboard'))
        else:
            flash('Invalid Staff ID or password!', 'danger')

    return render_template('staff_login.html')

@app.route('/student-login', methods=['GET', 'POST'])
def student_login():
    if request.method == 'POST':
        student_id = request.form.get('student_id', '').strip()
        password = request.form.get('password', '')

        students = load_students()
        member = next((s for s in students if s['id'] == student_id), None)

        if member and check_password_hash(member.get('password_hash', ''), password):
            session['student_logged_in'] = True
            session['student_id'] = member['id']
            session['student_name'] = member['name']
            flash(f"Welcome, {member['name']}!", 'success')
            return redirect(url_for('student_dashboard'))
        else:
            flash('Invalid Student ID or password!', 'danger')

    return render_template('student_login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully!', 'info')
    return redirect(url_for('login'))

@app.route('/dashboard')
def dashboard():
    if 'admin_logged_in' not in session:
        return redirect(url_for('login'))

    staff = load_staff()
    all_timetables = load_all_timetables()
    notifications = load_notifications()
    departments = load_departments()
    email_history = load_email_history()
    auto_state = load_auto_email_state()
    dept_counts = {d: len([s for s in staff if s.get('department') == d]) for d in departments}

    timetable_days = set()
    for dept_timetable in all_timetables.values():
        timetable_days.update(dept_timetable.keys())

    return render_template('dashboard.html',
                         staff_count=len(staff),
                         timetable_days=list(timetable_days),
                         notifications=notifications[-10:],
                         department_count=len(departments),
                         admin_username=session.get('admin_username'),
                         email_count=len(email_history),
                         auto_active=auto_state.get('active', False),
                         auto_run_count=auto_state.get('run_count', 0),
                         departments=departments,
                         dept_counts=dept_counts)

@app.route('/staff-dashboard')
def staff_dashboard():
    if 'staff_logged_in' not in session:
        return redirect(url_for('staff_login'))

    staff = load_staff()
    me = next((s for s in staff if s['id'] == session.get('staff_id')), None)
    my_department = me.get('department') if me else ''
    timetable = get_department_timetable(my_department)
    period_by_id = {p['id']: p for p in load_periods()}

    my_periods = []
    for day, periods in timetable.items():
        for period_id, details in periods.items():
            if details.get('staff_id') == session.get('staff_id'):
                p = period_by_id.get(period_id)
                label = period_display(p) if p else period_id
                my_periods.append({'day': day, 'period': label, 'subject': details.get('subject', '')})

    current_time = get_effective_system_time()

    return render_template('staff_dashboard.html',
                            me=me,
                            my_periods=my_periods,
                            department_count=len(load_departments()),
                            current_time_display=current_time.strftime('%A, %d %B %Y — %H:%M:%S'))

@app.route('/student-dashboard')
@student_required
def student_dashboard():
    students = load_students()
    me = next((s for s in students if s['id'] == session.get('student_id')), None)
    my_department = (me or {}).get('department', '')
    my_class = (me or {}).get('class_name', '')
    my_semester = (me or {}).get('semester', '')

    timetable = get_department_timetable(my_department)
    period_by_id = {p['id']: p for p in load_periods()}
    current_time = get_effective_system_time()
    today_day = current_time.strftime('%A')
    today_periods = []
    for period_id, details in timetable.get(today_day, {}).items():
        p = period_by_id.get(period_id)
        if not p:
            continue
        today_periods.append({
            'label': period_display(p), 'start': p.get('start', ''),
            'is_break': p.get('is_break', False),
            'subject': details.get('subject', ''), 'staff_name': details.get('staff_name', '')
        })
    today_periods.sort(key=lambda x: x.get('start', ''))

    return render_template('student_dashboard.html',
                            me=me,
                            my_department=my_department,
                            my_class=my_class,
                            my_semester=my_semester,
                            today_day=today_day,
                            today_periods=today_periods,
                            current_time_display=current_time.strftime('%A, %d %B %Y — %H:%M:%S'))

@app.route('/student-timetable')
@student_required
def student_timetable_page():
    students = load_students()
    me = next((s for s in students if s['id'] == session.get('student_id')), None)
    my_department = (me or {}).get('department', '')
    my_class = (me or {}).get('class_name', '')
    my_semester = (me or {}).get('semester', '')

    timetable = get_department_timetable(my_department)
    periods = load_periods()
    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']

    return render_template('student_timetable.html',
                            timetable=timetable,
                            days=days,
                            periods=periods,
                            my_department=my_department,
                            my_class=my_class,
                            my_semester=my_semester,
                            my_student_name=session.get('student_name'))

# ==================== ADMIN: STUDENT MANAGEMENT ====================

@app.route('/students')
@admin_required
def students_page():
    students = load_students()
    departments = load_departments()
    classes = load_classes()
    return render_template('students.html', students=students, departments=departments, classes=classes)

@app.route('/add_student', methods=['POST'])
@admin_required
def add_student():
    students_list = load_students()
    student_id = request.form.get('student_id', '').strip()
    new_student = {
        'name': request.form.get('name', '').strip(),
        'id': student_id,
        'email_id': request.form.get('email_id', '').strip(),
        'mobile_number': request.form.get('mobile_number', '').strip(),
        'department': request.form.get('department', '').strip(),
        'class_name': request.form.get('class_name', '').strip(),
        'semester': request.form.get('semester', '').strip(),
        'password_hash': generate_password_hash(str(student_id))
    }

    if not student_id or not new_student['name']:
        flash('Student ID and Name are required!', 'danger')
    elif any(s['id'] == student_id for s in students_list):
        flash('Student ID already exists!', 'danger')
    else:
        students_list.append(new_student)
        save_students(students_list)
        flash('Student added successfully! Default login password is their Student ID.', 'success')

    return redirect(url_for('students_page'))

@app.route('/delete_student/<student_id>')
@admin_required
def delete_student(student_id):
    students_list = load_students()
    students_list = [s for s in students_list if s['id'] != student_id]
    save_students(students_list)
    flash('Student deleted!', 'success')
    return redirect(url_for('students_page'))

# ==================== ADMIN: DYNAMIC CLASS MANAGEMENT ====================

@app.route('/add_class', methods=['POST'])
@admin_required
def add_class():
    class_name = request.form.get('class_name', '').strip()
    department = request.form.get('class_department', '').strip()
    semester = request.form.get('class_semester', '').strip()

    if not class_name or not department:
        flash('Class name and Department are required!', 'danger')
        return redirect(url_for('departments_page'))

    classes = load_classes()
    if any(c['name'].lower() == class_name.lower() and c['department'] == department for c in classes):
        flash('That class already exists in this department!', 'danger')
    else:
        classes.append({'name': class_name, 'department': department, 'semester': semester})
        save_classes(classes)
        flash(f'Class "{class_name}" added successfully!', 'success')

    return redirect(url_for('departments_page'))

@app.route('/delete_class/<path:class_name>')
@admin_required
def delete_class(class_name):
    students = load_students()
    in_use = any(s.get('class_name') == class_name for s in students)
    if in_use:
        flash(f'Cannot delete "{class_name}" — students are still assigned to it!', 'danger')
        return redirect(url_for('departments_page'))

    classes = load_classes()
    classes = [c for c in classes if c['name'] != class_name]
    save_classes(classes)
    flash(f'Class "{class_name}" deleted!', 'success')
    return redirect(url_for('departments_page'))

# ==================== CAMPUS CARE (integrated module) ====================
# Campus Care is a separate, self-contained application (its own HTML/CSS/JS
# and its own data layer). It is served as-is from static/campus_care so its
# internal logic is never touched. Access simply reuses the existing
# login_required check — no new auth system, no shared data with the
# Timetable Management System.

@app.route('/campus-care')
@login_required
def campus_care():
    campus_care_dir = os.path.join(app.root_path, 'static', 'campus_care')
    return send_from_directory(campus_care_dir, 'index.html')

# ---- Campus Care data layer (JSON file in the same DATA_DIR as everything else) ----

def load_campus_tickets():
    if os.path.exists(CAMPUS_TICKETS_FILE):
        with open(CAMPUS_TICKETS_FILE, 'r') as f:
            return json.load(f)
    return []

def save_campus_tickets(tickets):
    with open(CAMPUS_TICKETS_FILE, 'w') as f:
        json.dump(tickets, f, indent=2)

def next_ticket_id(tickets):
    n = 1
    existing = {t.get('id') for t in tickets}
    while f'TK-{n:03d}' in existing:
        n += 1
    return f'TK-{n:03d}'

CAMPUS_DEMO_TICKETS = [
    {'title': 'Canteen exhaust fan broken', 'category': 'Canteen', 'location': 'Main Canteen', 'reporter': 'Anonymous', 'status': 'Open', 'priority': 'High', 'date': '2024-08-01', 'desc': 'Exhaust fan not working, heat and smoke buildup. Urgent repair needed.', 'notes': '', 'likes': 5, 'comments': [{'author': 'S2024010', 'text': 'This is unbearable in the afternoon!', 'time': 'Aug 1'}, {'author': 'S2024022', 'text': 'Agreed, please fix urgently.', 'time': 'Aug 2'}]},
    {'title': 'Projector not turning on', 'category': 'Classroom', 'location': 'Block A, Room 101', 'reporter': 'Anonymous', 'status': 'In Progress', 'priority': 'Medium', 'date': '2024-08-02', 'desc': 'Projector fails to power on. Remote and manual button both tried.', 'notes': 'Technician assigned', 'likes': 2, 'comments': []},
    {'title': 'Main corridor lights flickering', 'category': 'Electrical', 'location': 'Block B, Ground Floor', 'reporter': 'Anonymous', 'status': 'Open', 'priority': 'High', 'date': '2024-08-02', 'desc': 'Lights flicker intermittently. Possible wiring issue. Safety hazard.', 'notes': '', 'likes': 3, 'comments': [{'author': 'S2024031', 'text': 'Very concerning for late night students.', 'time': 'Aug 2'}]},
    {'title': 'Washroom pipe leaking', 'category': 'Plumbing', 'location': 'Girls Hostel Block C', 'reporter': 'Anonymous', 'status': 'In Progress', 'priority': 'High', 'date': '2024-08-03', 'desc': 'Pipe under sink leaking continuously. Water pooling on floor.', 'notes': 'Plumber scheduled for tomorrow', 'likes': 7, 'comments': []},
    {'title': 'Bus 3 AC not working', 'category': 'Buses', 'location': 'Route 3 — City Loop', 'reporter': 'Anonymous', 'status': 'Open', 'priority': 'Medium', 'date': '2024-08-03', 'desc': 'Air conditioning on Bus 3 not working. 60+ students affected.', 'notes': '', 'likes': 12, 'comments': [{'author': 'S2024045', 'text': 'Extremely hot inside, please prioritize!', 'time': 'Aug 3'}]},
    {'title': 'WiFi down in Library', 'category': 'IT / Network', 'location': 'Central Library', 'reporter': 'Anonymous', 'status': 'Resolved', 'priority': 'Medium', 'date': '2024-07-30', 'desc': 'No WiFi for 2 days. Students unable to access e-resources.', 'notes': 'Router replaced', 'likes': 9, 'comments': []},
]

def campus_whoami_data():
    """Resolve the current CampusFix identity from the shared TMS session."""
    if is_admin():
        return {'role': 'admin', 'name': 'Admin Manager', 'id': 'ADMIN', 'department': ''}
    if is_staff():
        staff = load_staff()
        me = next((s for s in staff if s['id'] == session.get('staff_id')), None)
        return {
            'role': 'staff',
            'name': session.get('staff_name', 'Staff'),
            'id': session.get('staff_id', ''),
            'department': (me or {}).get('department', '')
        }
    if is_student():
        students = load_students()
        me = next((s for s in students if s['id'] == session.get('student_id')), None)
        return {
            'role': 'student',
            'name': session.get('student_name', 'Student'),
            'id': session.get('student_id', ''),
            'department': (me or {}).get('department', ''),
            'class_name': (me or {}).get('class_name', ''),
            'semester': (me or {}).get('semester', '')
        }
    return None

@app.route('/campus-care/api/whoami')
def campus_api_whoami():
    identity = campus_whoami_data()
    if not identity:
        return jsonify({'status': 'error', 'message': 'Not logged in'}), 401
    return jsonify(identity)

@app.route('/campus-care/api/tickets', methods=['GET'])
@login_required
def campus_api_list_tickets():
    tickets = load_campus_tickets()
    tickets_sorted = sorted(tickets, key=lambda t: t.get('createdAt', ''), reverse=True)
    return jsonify({'status': 'success', 'tickets': tickets_sorted})

@app.route('/campus-care/api/tickets', methods=['POST'])
@login_required
def campus_api_create_ticket():
    identity = campus_whoami_data()
    if not identity:
        return jsonify({'status': 'error', 'message': 'Not logged in'}), 401

    data = request.get_json(silent=True) or {}
    required = ['title', 'category', 'location', 'status', 'priority']
    if not all(str(data.get(k, '')).strip() for k in required):
        return jsonify({'status': 'error', 'message': 'Missing required ticket fields.'})

    tickets = load_campus_tickets()
    ticket = {
        'id': next_ticket_id(tickets),
        'title': data.get('title', ''),
        'category': data.get('category', ''),
        'location': data.get('location', ''),
        'reporter': data.get('reporter') or identity['name'],
        'reporterId': identity['id'],
        'contact': data.get('contact', ''),
        'status': data.get('status', 'Open'),
        'priority': data.get('priority', 'Medium'),
        'date': data.get('date', ''),
        'desc': data.get('desc', ''),
        'notes': data.get('notes', ''),
        'likes': int(data.get('likes', 0) or 0),
        'comments': data.get('comments', []) or [],
        'createdAt': datetime.now().strftime('%Y-%m-%dT%H:%M:%S'),
        'assigned_staff_id': '',
        'assigned_staff_name': '',
        'notify_active': False,
        'notify_interval_minutes': 10,
        'last_notified_at': None,
    }
    tickets.append(ticket)
    save_campus_tickets(tickets)
    return jsonify({'status': 'success', 'ticket': ticket})

@app.route('/campus-care/api/tickets/<ticket_id>', methods=['PATCH'])
@login_required
def campus_api_update_ticket(ticket_id):
    data = request.get_json(silent=True) or {}
    tickets = load_campus_tickets()
    ticket = next((t for t in tickets if t.get('id') == ticket_id), None)
    if not ticket:
        return jsonify({'status': 'error', 'message': 'Ticket not found.'})

    # Admin-only fields (mirrors the original client-side permission model,
    # enforced here too so a non-admin can't spoof these through the API).
    admin_only_fields = {'status', 'priority', 'notes'}
    if not is_admin() and any(f in data for f in admin_only_fields):
        return jsonify({'status': 'error', 'message': 'Admin only.'})

    allowed_fields = {'status', 'priority', 'notes', 'likes', 'comments'}
    for key, value in data.items():
        if key in allowed_fields:
            ticket[key] = value

    # Resolving a ticket automatically stops its continuous notification —
    # there's nothing left to keep reminding staff about. This never touches
    # other tickets' notifications.
    if ticket.get('status') == 'Resolved' and ticket.get('notify_active'):
        ticket['notify_active'] = False

    save_campus_tickets(tickets)
    return jsonify({'status': 'success', 'ticket': ticket})

@app.route('/campus-care/api/tickets/<ticket_id>', methods=['DELETE'])
@admin_required
def campus_api_delete_ticket(ticket_id):
    tickets = load_campus_tickets()
    remaining = [t for t in tickets if t.get('id') != ticket_id]
    if len(remaining) == len(tickets):
        return jsonify({'status': 'error', 'message': 'Ticket not found.'})
    save_campus_tickets(remaining)
    return jsonify({'status': 'success'})

@app.route('/campus-care/api/seed', methods=['POST'])
@admin_required
def campus_api_seed():
    tickets = load_campus_tickets()
    added = 0
    for demo in CAMPUS_DEMO_TICKETS:
        t = dict(demo)
        t['id'] = next_ticket_id(tickets)
        t['createdAt'] = datetime.now().strftime('%Y-%m-%dT%H:%M:%S')
        tickets.append(t)
        added += 1
    save_campus_tickets(tickets)
    return jsonify({'status': 'success', 'count': added})

# ==================== COMPLAINT CONTINUOUS NOTIFICATIONS ====================
# Once a ticket is assigned to a staff member, a background scheduler (see
# complaint_notify_worker, started once at boot — not tied to any browser
# session) keeps emailing that staff member every `notify_interval_minutes`
# until: the ticket is marked Resolved, Admin clicks STOP for that one
# ticket, or ALERT STAFF reassigns it. Stopping/reassigning one ticket only
# flips that ticket's own `notify_active` flag — the shared background loop
# that drives every other ticket's reminders keeps running untouched.

def complaint_build_message(staff_name, ticket):
    subject = f"CampusFix Alert — {ticket.get('title', 'Complaint')} ({ticket.get('id')})"
    body = (
        f"Dear {staff_name},\n\n"
        f"A CampusFix complaint is assigned to you and still needs attention:\n\n"
        f"  Ticket     : {ticket.get('id')}\n"
        f"  Title      : {ticket.get('title', '')}\n"
        f"  Category   : {ticket.get('category', '')}\n"
        f"  Location   : {ticket.get('location', '')}\n"
        f"  Priority   : {ticket.get('priority', '')}\n"
        f"  Status     : {ticket.get('status', '')}\n"
        f"  Reported   : {ticket.get('date', '')}\n\n"
        f"  Details    : {ticket.get('desc', '')}\n\n"
        f"You will keep receiving reminders about this complaint every "
        f"{ticket.get('notify_interval_minutes', 10)} minute(s) until it is resolved, "
        f"an Admin stops this reminder, or it is reassigned to someone else.\n"
    )
    return subject, body

def load_complaint_notify_log():
    if os.path.exists(COMPLAINT_NOTIFY_LOG_FILE):
        with open(COMPLAINT_NOTIFY_LOG_FILE, 'r') as f:
            return json.load(f)
    return []

def save_complaint_notify_log(log):
    with open(COMPLAINT_NOTIFY_LOG_FILE, 'w') as f:
        json.dump(log, f, indent=2)

def complaint_notify_send(ticket, staff_member, event='reminder'):
    """Sends one notification email for a ticket, and always records it in
    the persistent history — this is what 'save notification history' and
    'prevent duplicate emails' rely on."""
    subject, body = complaint_build_message(staff_member['name'], ticket)
    success, info = send_email(staff_member.get('email_id', ''), subject, body)

    log = load_complaint_notify_log()
    log.append({
        'ticket_id': ticket.get('id'), 'ticket_title': ticket.get('title', ''),
        'staff_id': staff_member.get('id'), 'staff_name': staff_member.get('name'),
        'event': event,
        'sent_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'status': 'Sent' if success else f'Failed - {info}',
    })
    save_complaint_notify_log(log)

    tickets = load_campus_tickets()
    t = next((x for x in tickets if x.get('id') == ticket.get('id')), None)
    if t:
        t['last_notified_at'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        save_campus_tickets(tickets)
    return success

@app.route('/campus-care/api/staff-list')
@admin_required
def campus_api_staff_list():
    staff = load_staff()
    return jsonify({'status': 'success',
                     'staff': [{'id': s['id'], 'name': s['name'], 'department': s.get('department', '')} for s in staff]})

@app.route('/campus-care/api/tickets/<ticket_id>/assign', methods=['POST'])
@admin_required
def campus_api_assign_ticket(ticket_id):
    data = request.get_json(silent=True) or {}
    staff_id = (data.get('staff_id') or '').strip()
    interval = data.get('interval_minutes', 10)
    try:
        interval = max(1, int(interval))
    except (TypeError, ValueError):
        interval = 10

    staff_member = next((s for s in load_staff() if s['id'] == staff_id), None)
    if not staff_member:
        return jsonify({'status': 'error', 'message': 'Select a valid staff member to assign.'})

    tickets = load_campus_tickets()
    ticket = next((t for t in tickets if t.get('id') == ticket_id), None)
    if not ticket:
        return jsonify({'status': 'error', 'message': 'Ticket not found.'})

    ticket['assigned_staff_id'] = staff_id
    ticket['assigned_staff_name'] = staff_member['name']
    ticket['notify_active'] = True
    ticket['notify_interval_minutes'] = interval
    ticket['last_notified_at'] = None
    save_campus_tickets(tickets)

    complaint_notify_send(ticket, staff_member, event='assigned')
    return jsonify({'status': 'success', 'message': f"Assigned to {staff_member['name']} and notified."})

@app.route('/campus-care/api/tickets/<ticket_id>/stop-notify', methods=['POST'])
@admin_required
def campus_api_stop_notify(ticket_id):
    tickets = load_campus_tickets()
    ticket = next((t for t in tickets if t.get('id') == ticket_id), None)
    if not ticket:
        return jsonify({'status': 'error', 'message': 'Ticket not found.'})

    # Only this ticket's flag changes — every other ticket's reminders,
    # and the full-day background scheduler itself, are unaffected.
    ticket['notify_active'] = False
    save_campus_tickets(tickets)
    return jsonify({'status': 'success', 'message': 'Notifications stopped for this complaint.'})

@app.route('/campus-care/api/tickets/<ticket_id>/alert-staff', methods=['POST'])
@admin_required
def campus_api_alert_staff(ticket_id):
    tickets = load_campus_tickets()
    ticket = next((t for t in tickets if t.get('id') == ticket_id), None)
    if not ticket:
        return jsonify({'status': 'error', 'message': 'Ticket not found.'})

    staff = load_staff()
    if not staff:
        return jsonify({'status': 'error', 'message': 'No staff members exist to reassign to.'})

    current_staff_id = ticket.get('assigned_staff_id', '')
    # Prefer another staff member from the same department as whoever's
    # currently assigned, otherwise fall back to anyone else.
    current_member = next((s for s in staff if s['id'] == current_staff_id), None)
    pool = [s for s in staff if s['id'] != current_staff_id]
    if current_member:
        same_dept = [s for s in pool if s.get('department') == current_member.get('department')]
        if same_dept:
            pool = same_dept
    if not pool:
        pool = staff  # only one staff member exists — re-alert them

    new_staff = random.choice(pool)

    # Stop the current notification for this ticket only, then hand off.
    ticket['notify_active'] = False
    save_campus_tickets(tickets)

    log = load_complaint_notify_log()
    log.append({
        'ticket_id': ticket.get('id'), 'ticket_title': ticket.get('title', ''),
        'staff_id': current_staff_id, 'staff_name': ticket.get('assigned_staff_name', ''),
        'event': 'stopped_for_reassignment',
        'sent_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 'status': 'Stopped',
    })
    save_complaint_notify_log(log)

    tickets = load_campus_tickets()
    ticket = next((t for t in tickets if t.get('id') == ticket_id), None)
    ticket['assigned_staff_id'] = new_staff['id']
    ticket['assigned_staff_name'] = new_staff['name']
    ticket['notify_active'] = True
    ticket['last_notified_at'] = None
    save_campus_tickets(tickets)

    complaint_notify_send(ticket, new_staff, event='reassigned_alert')
    return jsonify({'status': 'success',
                     'message': f"Stopped previous reminder and alerted {new_staff['name']} instead."})

@app.route('/complaint-notify-log')
@admin_required
def complaint_notify_log_page():
    log = load_complaint_notify_log()
    tickets = {t['id']: t for t in load_campus_tickets()}
    return render_template('complaint_notify_log.html', log=list(reversed(log)), tickets=tickets)

# ==================== END COMPLAINT NOTIFICATIONS ====================

@app.route('/staff')
def staff_page():
    if 'admin_logged_in' not in session:
        return redirect(url_for('login'))

    staff = load_staff()
    departments = load_departments()
    return render_template('staff.html', staff=staff, departments=departments)

@app.route('/upload_staff', methods=['POST'])
def upload_staff():
    if 'admin_logged_in' not in session:
        return redirect(url_for('login'))

    if 'file' not in request.files:
        flash('No file selected!', 'danger')
        return redirect(url_for('staff_page'))

    file = request.files['file']
    if file.filename == '':
        flash('No file selected!', 'danger')
        return redirect(url_for('staff_page'))

    if file and (file.filename.endswith('.xlsx') or file.filename.endswith('.xls') or file.filename.endswith('.csv')):
        filename = secure_filename(file.filename)
        filepath = os.path.join(UPLOAD_DIR, filename)
        file.save(filepath)

        try:
            if filename.endswith('.csv'):
                df = pd.read_csv(filepath)
            else:
                df = pd.read_excel(filepath)

            required_cols = ['name', 'id', 'mobile_number', 'department', 'email_id']
            df.columns = df.columns.str.strip().str.lower().str.replace(' ', '_')

            staff_list = load_staff()

            for _, row in df.iterrows():
                staff_id = str(row.get('id', ''))
                staff_member = {
                    'name': str(row.get('name', '')),
                    'id': staff_id,
                    'mobile_number': str(row.get('mobile_number', '')),
                    'department': str(row.get('department', '')),
                    'email_id': str(row.get('email_id', '')),
                    'password_hash': generate_password_hash(staff_id)
                }
                # Avoid duplicates by ID
                existing = [s for s in staff_list if s['id'] == staff_member['id']]
                if not existing:
                    staff_list.append(staff_member)

            save_staff(staff_list)
            flash(f'Successfully uploaded {len(df)} staff members!', 'success')
        except Exception as e:
            flash(f'Error processing file: {str(e)}', 'danger')
    else:
        flash('Please upload an Excel (.xlsx/.xls) or CSV file!', 'danger')

    return redirect(url_for('staff_page'))

@app.route('/add_staff', methods=['POST'])
def add_staff():
    if 'admin_logged_in' not in session:
        return redirect(url_for('login'))

    staff_list = load_staff()
    staff_id = request.form.get('staff_id')
    new_staff = {
        'name': request.form.get('name'),
        'id': staff_id,
        'mobile_number': request.form.get('mobile_number'),
        'department': request.form.get('department'),
        'email_id': request.form.get('email_id'),
        'password_hash': generate_password_hash(str(staff_id))
    }

    existing = [s for s in staff_list if s['id'] == new_staff['id']]
    if existing:
        flash('Staff ID already exists!', 'danger')
    else:
        staff_list.append(new_staff)
        save_staff(staff_list)
        flash('Staff member added successfully! Default login password is their Staff ID.', 'success')

    return redirect(url_for('staff_page'))

@app.route('/delete_staff/<staff_id>')
def delete_staff(staff_id):
    if 'admin_logged_in' not in session:
        return redirect(url_for('login'))

    staff_list = load_staff()
    staff_list = [s for s in staff_list if s['id'] != staff_id]
    save_staff(staff_list)
    flash('Staff member deleted!', 'success')
    return redirect(url_for('staff_page'))

@app.route('/departments')
def departments_page():
    if 'admin_logged_in' not in session:
        return redirect(url_for('login'))

    departments = load_departments()
    staff = load_staff()
    students = load_students()
    classes = load_classes()

    # Count staff per department
    dept_counts = {}
    for dept in departments:
        dept_counts[dept] = len([s for s in staff if s.get('department') == dept])

    class_student_counts = {c['name']: len([s for s in students if s.get('class_name') == c['name']]) for c in classes}

    return render_template('departments.html', departments=departments, dept_counts=dept_counts,
                            classes=classes, class_student_counts=class_student_counts)

@app.route('/add_department', methods=['POST'])
def add_department():
    if 'admin_logged_in' not in session:
        return redirect(url_for('login'))

    dept_name = request.form.get('department_name', '').strip()

    if not dept_name:
        flash('Department name cannot be empty!', 'danger')
        return redirect(url_for('departments_page'))

    departments = load_departments()

    if any(d.lower() == dept_name.lower() for d in departments):
        flash('Department already exists!', 'danger')
    else:
        departments.append(dept_name)
        save_departments(departments)
        flash(f'Department "{dept_name}" added successfully!', 'success')

    return redirect(url_for('departments_page'))

@app.route('/delete_department/<dept_name>')
def delete_department(dept_name):
    if 'admin_logged_in' not in session:
        return redirect(url_for('login'))

    staff = load_staff()
    in_use = any(s.get('department') == dept_name for s in staff)

    if in_use:
        flash(f'Cannot delete "{dept_name}" — it is still assigned to staff members!', 'danger')
        return redirect(url_for('departments_page'))

    departments = load_departments()
    departments = [d for d in departments if d != dept_name]
    save_departments(departments)
    flash(f'Department "{dept_name}" deleted!', 'success')
    return redirect(url_for('departments_page'))

@app.route('/settings', methods=['GET', 'POST'])
def settings_page():
    if 'admin_logged_in' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        config = {
            'smtp_server': request.form.get('smtp_server', 'smtp.gmail.com').strip(),
            'smtp_port': int(request.form.get('smtp_port', 587)),
            'sender_email': request.form.get('sender_email', '').strip(),
            'sender_password': request.form.get('sender_password', '').strip(),
            'use_tls': True
        }
        save_smtp_config(config)
        flash('Email settings saved!', 'success')
        return redirect(url_for('settings_page'))

    config = load_smtp_config()
    return render_template('settings.html', config=config)

@app.route('/timetable')
def timetable_page():
    if 'admin_logged_in' not in session:
        return redirect(url_for('login'))

    departments = load_departments()
    selected_department = request.args.get('department') or (departments[0] if departments else '')

    timetable = get_department_timetable(selected_department)
    staff = load_staff()
    periods = load_periods()

    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']

    return render_template('timetable.html',
                         timetable=timetable,
                         staff=staff,
                         days=days,
                         periods=periods,
                         departments=departments,
                         selected_department=selected_department)

@app.route('/my-timetable')
def my_timetable_page():
    if 'staff_logged_in' not in session:
        return redirect(url_for('staff_login'))

    staff = load_staff()
    me = next((s for s in staff if s['id'] == session.get('staff_id')), None)
    my_department = me.get('department') if me else ''

    timetable = get_department_timetable(my_department)
    periods = load_periods()
    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']

    return render_template('my_timetable.html',
                            timetable=timetable,
                            days=days,
                            periods=periods,
                            my_staff_id=session.get('staff_id'),
                            my_staff_name=session.get('staff_name'),
                            my_department=my_department)

@app.route('/save_timetable', methods=['POST'])
def save_timetable_route():
    if 'admin_logged_in' not in session:
        return jsonify({'status': 'error', 'message': 'Not logged in'})

    data = request.get_json()
    department = (data.get('department') or '').strip()
    timetable = data.get('timetable', {})

    if not department:
        return jsonify({'status': 'error', 'message': 'No department selected — pick a department first.'})

    save_department_timetable(department, timetable)

    return jsonify({'status': 'success', 'message': f'Timetable for {department} saved!'})

@app.route('/ai_generate_timetable', methods=['POST'])
def ai_generate_timetable():
    if 'admin_logged_in' not in session:
        return jsonify({'status': 'error', 'message': 'Not logged in'})

    data = request.get_json(silent=True) or {}
    department = (data.get('department') or '').strip()
    if not department:
        return jsonify({'status': 'error', 'message': 'No department selected — pick a department first.'})

    staff = [s for s in load_staff() if s.get('department') == department]
    if len(staff) == 0:
        return jsonify({'status': 'error', 'message': f'No staff members found in {department}!'})

    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
    working_periods = [p for p in load_periods() if not p.get('is_break')]

    subjects = ['Mathematics', 'Physics', 'Chemistry', 'Biology', 'English',
                'Computer Science', 'History', 'Geography', 'Economics', 'Physical Education']

    timetable = {}

    for day in days:
        timetable[day] = {}
        available_staff = staff.copy()
        random.shuffle(available_staff)

        for p in working_periods:
            if available_staff:
                assigned = available_staff.pop(0)
                subject = random.choice(subjects)
                timetable[day][p['id']] = {
                    'staff_id': assigned['id'],
                    'staff_name': assigned['name'],
                    'subject': subject,
                    'department': assigned['department']
                }
                # Put back for next period (staff can have multiple periods)
                available_staff.append(assigned)
                random.shuffle(available_staff)
            else:
                timetable[day][p['id']] = {
                    'staff_id': '',
                    'staff_name': 'No Staff Available',
                    'subject': 'Free Period',
                    'department': ''
                }

    save_department_timetable(department, timetable)

    return jsonify({'status': 'success', 'message': f'AI-generated timetable created for {department}!', 'timetable': timetable})

@app.route('/save_periods', methods=['POST'])
@admin_required
def save_periods_route():
    data = request.get_json() or {}
    periods = data.get('periods', [])

    if not isinstance(periods, list) or len(periods) == 0:
        return jsonify({'status': 'error', 'message': 'You need at least one period row.'})

    cleaned = []
    seen_ids = set()
    for i, p in enumerate(periods):
        label = str(p.get('label', '')).strip() or f'Period {i + 1}'
        start = str(p.get('start', '')).strip() or '9:00'
        end = str(p.get('end', '')).strip() or '10:00'
        is_break = bool(p.get('is_break', False))
        pid = str(p.get('id', '')).strip() or f"custom_{i}_{int(datetime.now().timestamp())}"

        base_id, counter = pid, 1
        while pid in seen_ids:
            pid = f"{base_id}_{counter}"
            counter += 1
        seen_ids.add(pid)

        cleaned.append({'id': pid, 'label': label, 'start': start, 'end': end, 'is_break': is_break})

    save_periods(cleaned)
    return jsonify({'status': 'success', 'message': 'Periods updated successfully!', 'periods': cleaned})

@app.route('/get_timetable')
def get_timetable():
    if 'admin_logged_in' not in session:
        return jsonify({'status': 'error'})

    department = request.args.get('department', '')
    timetable = get_department_timetable(department)
    return jsonify({'status': 'success', 'timetable': timetable})

@app.route('/notifications')
def notifications_page():
    if 'admin_logged_in' not in session:
        return redirect(url_for('login'))

    notifications = load_notifications()
    return render_template('notifications.html', notifications=notifications)

@app.route('/send_notification', methods=['POST'])
def send_notification():
    if 'admin_logged_in' not in session:
        return jsonify({'status': 'error'})

    data = request.get_json()
    message = data.get('message', '')
    staff_id = data.get('staff_id', '')
    custom_email = data.get('custom_email', '').strip()
    subject = data.get('subject', '').strip() or 'Timetable Management Notification'

    notifications = load_notifications()
    sent_count = 0
    failed_count = 0

    if custom_email:
        # Send directly to a specific, given email address
        success, info = send_email(custom_email, subject, message)
        notification = {
            'id': len(notifications) + 1,
            'staff_id': '',
            'staff_name': custom_email,
            'mobile': '',
            'email_id': custom_email,
            'message': message,
            'sent_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'status': 'Sent (Email)' if success else f'Failed - {info}'
        }
        notifications.append(notification)
        save_notifications(notifications)

        if success:
            return jsonify({'status': 'success', 'message': f'Email sent to {custom_email}!'})
        else:
            return jsonify({'status': 'error', 'message': info})

    staff = load_staff()
    target_staff = [s for s in staff if s['id'] == staff_id] if staff_id else staff

    for s in target_staff:
        success, info = send_email(s.get('email_id', ''), subject, message)
        if success:
            sent_count += 1
        else:
            failed_count += 1

        notification = {
            'id': len(notifications) + 1,
            'staff_id': s['id'],
            'staff_name': s['name'],
            'mobile': s['mobile_number'],
            'email_id': s.get('email_id', ''),
            'message': message,
            'sent_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'status': 'Sent (Email)' if success else f'Failed - {info}'
        }
        notifications.append(notification)

    save_notifications(notifications)

    summary = f'Sent to {sent_count} staff member(s).'
    if failed_count:
        summary += f' {failed_count} failed — check Settings for SMTP configuration.'

    return jsonify({'status': 'success' if sent_count else 'error', 'message': summary})

@app.route('/export_timetable')
def export_timetable():
    if 'admin_logged_in' not in session:
        return redirect(url_for('login'))

    department = request.args.get('department', '')
    timetable = get_department_timetable(department)
    period_by_id = {p['id']: p for p in load_periods()}

    if not timetable:
        flash(f'No timetable to export for {department}!' if department else 'Select a department first!', 'danger')
        return redirect(url_for('timetable_page', department=department))

    # Create Excel file
    safe_dept = secure_filename(department) or 'export'
    export_path = os.path.join(UPLOAD_DIR, f'timetable_export_{safe_dept}.xlsx')

    with pd.ExcelWriter(export_path, engine='openpyxl') as writer:
        for day, periods in timetable.items():
            data = []
            for period_id, details in periods.items():
                p = period_by_id.get(period_id)
                data.append({
                    'Day': day,
                    'Period': period_display(p) if p else period_id,
                    'Staff Name': details.get('staff_name', ''),
                    'Staff ID': details.get('staff_id', ''),
                    'Subject': details.get('subject', ''),
                    'Department': details.get('department', '')
                })
            df = pd.DataFrame(data)
            df.to_excel(writer, sheet_name=day[:31], index=False)

    return send_file(export_path, as_attachment=True, download_name=f'timetable_{safe_dept}.xlsx')

# ==================== SYSTEM DATE & TIME ROUTES ====================

@app.route('/system-time')
@login_required
def system_time_page():
    current = get_effective_system_time()
    state = load_system_time_state()
    return render_template('system_time.html',
                            current_time=current.strftime('%Y-%m-%d %H:%M:%S'),
                            current_time_iso=current.strftime('%Y-%m-%dT%H:%M:%S'),
                            is_custom=bool(state.get('base_custom')),
                            set_by=state.get('set_by'))

@app.route('/system-time/set', methods=['POST'])
@admin_required
def set_system_time():
    new_dt_str = request.form.get('new_datetime', '').strip()
    try:
        new_dt = datetime.strptime(new_dt_str, '%Y-%m-%dT%H:%M')
    except ValueError:
        flash('Please provide a valid date and time.', 'danger')
        return redirect(url_for('system_time_page'))

    state = {
        'base_real': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'base_custom': new_dt.strftime('%Y-%m-%d %H:%M:%S'),
        'set_by': session.get('admin_username', 'admin')
    }
    save_system_time_state(state)
    flash('System date & time updated successfully!', 'success')
    return redirect(url_for('system_time_page'))

@app.route('/system-time/reset', methods=['POST'])
@admin_required
def reset_system_time():
    save_system_time_state({'base_real': None, 'base_custom': None, 'set_by': None})
    flash('System date & time reset to the real device clock.', 'info')
    return redirect(url_for('system_time_page'))

# ==================== EMAIL CENTER (GENERATOR + AUTO-SEND) ====================

@app.route('/email-center')
@admin_required
def email_center_page():
    staff = load_staff()
    state = load_auto_email_state()
    return render_template('email_center.html', staff_count=len(staff), auto_state=state,
                            default_email_templates=DEFAULT_EMAIL_TEMPLATES)

@app.route('/generate_email', methods=['POST'])
@admin_required
def generate_email():
    data = request.get_json() or {}
    topic = data.get('topic', '')
    key_points = data.get('key_points', '')
    tone = data.get('tone', 'formal')
    sender_name = data.get('sender_name', 'Administration')

    if not topic.strip():
        return jsonify({'status': 'error', 'message': 'Please enter a topic for the announcement.'})

    subject, body = generate_email_content(topic, key_points, tone, sender_name)
    return jsonify({'status': 'success', 'subject': subject, 'body': body})

@app.route('/default_email_templates')
@admin_required
def default_email_templates():
    return jsonify({'status': 'success', 'templates': DEFAULT_EMAIL_TEMPLATES})

@app.route('/send_bulk_email', methods=['POST'])
@admin_required
def send_bulk_email():
    data = request.get_json() or {}
    subject = data.get('subject', '').strip()
    body = data.get('body', '').strip()

    if not subject or not body:
        return jsonify({'status': 'error', 'message': 'Subject and message body are required.'})

    sent, failed, total = dispatch_bulk_email(subject, body, source='manual')

    if total == 0:
        return jsonify({'status': 'error', 'message': 'There are no registered staff members to email yet.'})

    message = f'Email sent to {sent} of {total} staff member(s).'
    if failed:
        message += f' {failed} failed — check Settings for SMTP configuration.'

    return jsonify({'status': 'success' if sent else 'error', 'message': message})

@app.route('/start_auto_email', methods=['POST'])
@admin_required
def start_auto_email():
    global auto_email_thread

    with auto_email_lock:
        state = load_auto_email_state()
        if state.get('active'):
            return jsonify({'status': 'error', 'message': 'Automatic sending is already running. Stop it first.'})

        data = request.get_json() or {}
        subject = data.get('subject', '').strip()
        body = data.get('body', '').strip()
        try:
            interval_minutes = float(data.get('interval_minutes', 5) or 5)
        except (TypeError, ValueError):
            interval_minutes = 5

        if not subject or not body:
            return jsonify({'status': 'error', 'message': 'Subject and message body are required.'})

        interval_seconds = max(30, int(interval_minutes * 60))

        auto_email_stop_event.clear()
        new_state = {
            'active': True,
            'subject': subject,
            'body': body,
            'interval_seconds': interval_seconds,
            'started_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'last_run_at': None,
            'run_count': 0
        }
        save_auto_email_state(new_state)

        auto_email_thread = threading.Thread(
            target=auto_email_worker, args=(subject, body, interval_seconds), daemon=True
        )
        auto_email_thread.start()

    return jsonify({'status': 'success', 'message': 'Automatic email sending started — it will repeat until you click Stop.'})

@app.route('/stop_auto_email', methods=['POST'])
@admin_required
def stop_auto_email():
    auto_email_stop_event.set()
    state = load_auto_email_state()
    state['active'] = False
    save_auto_email_state(state)
    return jsonify({'status': 'success', 'message': 'Automatic email sending stopped.'})

@app.route('/auto_email_status')
@admin_required
def auto_email_status():
    return jsonify(load_auto_email_state())

@app.route('/email-history')
@admin_required
def email_history_page():
    history = load_email_history()
    return render_template('email_history.html', history=history)

# ---- Timetable-based auto-send (Start/Stop) ----

# ---- Timetable-based auto-send (Start/Stop) ----
# The scheduler thread (timetable_auto_worker) is started once, unconditionally,
# when the server boots (see the bottom of this file) — so it is always running
# in the background regardless of any browser tab or Admin login/logout. These
# two routes only flip the persisted 'active' flag it checks every minute;
# they never create or kill the thread itself, so nothing about restarting a
# browser or logging back in is required for reminders to keep going.

@app.route('/start_auto_email_timetable', methods=['POST'])
@admin_required
def start_auto_email_timetable():
    with timetable_auto_lock:
        state = load_timetable_auto_state()
        if state.get('active'):
            return jsonify({'status': 'error', 'message': 'Timetable auto-sending is already running.'})

        state['active'] = True
        state['started_at'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        save_timetable_auto_state(state)

    return jsonify({'status': 'success', 'message': 'Timetable-based auto-sending started. It checks every minute and emails staff 5 minutes before each of their periods, based on the live timetable.'})

@app.route('/stop_auto_email_timetable', methods=['POST'])
@admin_required
def stop_auto_email_timetable():
    state = load_timetable_auto_state()
    state['active'] = False
    save_timetable_auto_state(state)
    return jsonify({'status': 'success', 'message': 'Timetable-based auto-sending stopped.'})

@app.route('/timetable_auto_status')
@admin_required
def timetable_auto_status():
    state = load_timetable_auto_state()
    log = load_timetable_email_log()
    alerted = sum(1 for e in log if e.get('alerted'))
    stopped = sum(1 for e in log if e.get('stopped'))
    state['total_sent'] = len(log)
    state['total_alerted'] = alerted
    state['total_stopped'] = stopped
    return jsonify(state)

@app.route('/timetable-email-log')
@admin_required
def timetable_email_log_page():
    log = sorted(load_timetable_email_log(), key=lambda e: e.get('sent_at', ''), reverse=True)
    return render_template('timetable_email_log.html', log=log)

# ---- Public ALERT / STOP links (clicked from the email itself, no login needed) ----

@app.route('/email-action/<action>/<token>')
def timetable_email_action(action, token):
    if action not in ('alert', 'stop'):
        return render_template('email_action_result.html', ok=False,
                                message='Unrecognized action.')

    log = load_timetable_email_log()
    entry = next((e for e in log if e.get('token') == token), None)
    if not entry:
        return render_template('email_action_result.html', ok=False,
                                message='This link is invalid or has already expired.')

    now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    if action == 'alert':
        if not entry.get('alerted'):
            entry['alerted'] = True
            entry['alerted_at'] = now_str
            save_timetable_email_log(log)
        return render_template('email_action_result.html', ok=True, action='alert',
                                message=f"Thanks, {entry.get('staff_name','')}! Your alert for "
                                        f"{entry.get('subject','')} ({entry.get('period_id','')}) has been recorded.")
    else:
        if not entry.get('stopped'):
            entry['stopped'] = True
            entry['stopped_at'] = now_str
            save_timetable_email_log(log)
        return render_template('email_action_result.html', ok=True, action='stop',
                                message=f"Got it, {entry.get('staff_name','')}. You won't receive further "
                                        f"reminders for this recurring class slot.")

# Background scheduler for notifications
def notification_scheduler():
    while True:
        try:
            all_timetables = load_all_timetables()
            staff = load_staff()
            period_by_id = {p['id']: p for p in load_periods()}
            now = datetime.now()

            for department, timetable in all_timetables.items():
                for day, periods in timetable.items():
                    if day != now.strftime('%A'):
                        continue
                    for period_id, details in periods.items():
                        p = period_by_id.get(period_id)
                        if not p or p.get('is_break') or not p.get('start'):
                            continue
                        try:
                            start_time = datetime.strptime(p['start'].strip(), '%H:%M')
                        except ValueError:
                            continue
                        notify_time = start_time - timedelta(minutes=15)

                        if now.hour == notify_time.hour and now.minute == notify_time.minute:
                            staff_member = next((s for s in staff if s['id'] == details.get('staff_id')), None)
                            if staff_member:
                                message = f"Reminder: Your {details.get('subject', 'class')} class starts in 5 minutes!"
                                success, info = send_email(
                                    staff_member.get('email_id', ''),
                                    'Timetable Management - Class Reminder',
                                    message
                                )
                                notifications = load_notifications()
                                notification = {
                                    'id': len(notifications) + 1,
                                    'staff_id': staff_member['id'],
                                    'staff_name': staff_member['name'],
                                    'mobile': staff_member['mobile_number'],
                                    'email_id': staff_member.get('email_id', ''),
                                    'message': message,
                                    'sent_at': now.strftime('%Y-%m-%d %H:%M:%S'),
                                    'status': 'Auto-Scheduled (Email)' if success else f'Auto-Scheduled Failed - {info}'
                                }
                                notifications.append(notification)
                                save_notifications(notifications)

            time.sleep(60)  # Check every minute
        except Exception as e:
            print(f"Scheduler error: {e}")
            time.sleep(60)

# Start background scheduler
scheduler_thread = threading.Thread(target=notification_scheduler, daemon=True)
scheduler_thread.start()

# Timetable-based reminder scheduler — always running from server boot,
# independent of any browser tab or Admin session. Start/Stop just flip a
# persisted flag it checks every minute (see start_auto_email_timetable /
# stop_auto_email_timetable above).
timetable_auto_thread = threading.Thread(target=timetable_auto_worker, daemon=True)
timetable_auto_thread.start()

# Background scheduler for complaint (CampusFix) notifications — always
# running from the moment the server starts, independent of any browser
# tab or admin session, so reminders keep going even if everyone logs out.
def complaint_notify_scheduler():
    while True:
        try:
            tickets = load_campus_tickets()
            staff = load_staff()
            now = datetime.now()
            changed = False

            for ticket in tickets:
                if not ticket.get('notify_active'):
                    continue
                if ticket.get('status') == 'Resolved':
                    ticket['notify_active'] = False
                    changed = True
                    continue

                staff_member = next((s for s in staff if s['id'] == ticket.get('assigned_staff_id')), None)
                if not staff_member:
                    continue

                interval = int(ticket.get('notify_interval_minutes') or 10)
                last_sent = ticket.get('last_notified_at')
                due = True
                if last_sent:
                    try:
                        last_dt = datetime.strptime(last_sent, '%Y-%m-%d %H:%M:%S')
                        due = (now - last_dt) >= timedelta(minutes=interval)
                    except ValueError:
                        due = True

                if due:
                    complaint_notify_send(ticket, staff_member, event='reminder')

            if changed:
                save_campus_tickets(tickets)
        except Exception as e:
            print(f'Complaint notify scheduler error: {e}')

        time.sleep(60)  # Check every minute — keeps duplicate emails out since
                         # each ticket only becomes "due" once per interval.

complaint_notify_thread = threading.Thread(target=complaint_notify_scheduler, daemon=True)
complaint_notify_thread.start()

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000, threaded=True)
