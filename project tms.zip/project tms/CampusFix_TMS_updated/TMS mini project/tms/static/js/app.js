// Timetable Management System - shared front-end behaviors

document.addEventListener('DOMContentLoaded', function () {
    // Auto-dismiss flash message toasts after a few seconds
    document.querySelectorAll('.app-toast').forEach(function (toast, idx) {
        setTimeout(function () {
            toast.classList.add('toast-fade-out');
            setTimeout(function () {
                if (toast.parentNode) toast.parentNode.removeChild(toast);
            }, 400);
        }, 4500 + idx * 300);
    });

    // Animated count-up for dashboard stat numbers
    document.querySelectorAll('.counter').forEach(function (el) {
        const target = parseInt(el.dataset.count || '0', 10);
        if (!target) { el.textContent = '0'; return; }
        const duration = 700;
        const start = performance.now();
        function tick(now) {
            const progress = Math.min((now - start) / duration, 1);
            const value = Math.floor(progress * target);
            el.textContent = value;
            if (progress < 1) requestAnimationFrame(tick);
            else el.textContent = target;
        }
        requestAnimationFrame(tick);
    });
});
